## Confidence

![[confidence_tool]]
## Useful Function List

| Function_name        | Description                                      | Input                     | Output                |
| -------------------- | ------------------------------------------------ | ------------------------- | --------------------- |
| [[definedatum]]      | 根据指定的datum点，来计算出点在X_中的索引array。 | ("y:x",[9 6]);            | [y_i,x_i,y_all,x_all] |
| [[Ext]]              | 命名，提取文件中的数据。                         |                           |                       |
| [[normalizeX_]]      | Convert, or inverse the normalization of X_      | X_data,[y_i;x_i],"order") | [X_data,is_center]    |
| [[S transformation]] |                                                  |                           |                       |
| [[findDIR]]          |                                                  |                           |                       |
| [[u2u]]              |                                                  |                           |                       |
| [[add_constraint]]   |                                                  |                           |                       |
| [[AnalyzeEList]]     |                                                  |                           |                       |
| [[definedatum]]      |                                                  |                           |                       |
| [[expand_V]]         |                                                  |                           |                       |
| [[findDIR]]          |                                                  |                           |                       |
| [[findVar]]          |                                                  |                           |                       |
| [[Get_Funclist]]     |                                                  |                           |                       |
| [[normalizeX_]]      |                                                  |                           |                       |
| [[ppm]]              |                                                  |                           |                       |
| [[S_transform]]      |                                                  |                           |                       |
| [[XXX_VarPro]]       |                                                  |                           |                       |
|   [[expand_V]]                   |                                                  |                           |                       |


 