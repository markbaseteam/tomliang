



## Template

```matlab
Elist=["Free_=||"
    "Free_data=[]"
    "L_=|x|y dd ee|H [4 1]|Ext('6fix1.txt','yl:xl:YX','PTYX')|"
    "L_data=[123;zeros(4,3);Ext('B4dis.txt','H_diff:H','DIS')]"
    "X_=|Ext('6new1.txt','y:x','PTYX')|Ext('6dir1.txt','w','W')|"
    "X_data=[Ext('6new1.txt','y:x','PTYX');Ext('6dir1.txt','w','W')]"
	"LB_=|cons [3 1]|"
	"LB_data=[zeros(3,1)]"
```
