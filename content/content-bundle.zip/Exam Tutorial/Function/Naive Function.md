
## Code

| Function         |                                            |     |
| ---------------- | ------------------------------------------ | --- |
| Distance 1~2     | ```F_=[Get_Dis(x1,y1,x2,y2)]; ```          |     |
| Angle 1-i-2      | ```F_=[Get_Angles(xi,yi,x1,y1,x2,y2)]; ``` |     |
| Direction i to 1 | ```F_=[Get_Direction(xi,yi,x1,y1)]; ```    |     |

 