It will automatically convert all unit to unit of m / rad.  or vice versa.
## Template
 ```
u2u("2cm 2gon") 
u2u("10^m") u2u("2cm") u2u("2km") u2u("2gon") u2u("1mgon")  
u2u("10^tom") u2u("2tocm") u2u("2tokm") u2u("2togon") u2u("1tomgon")  
```
