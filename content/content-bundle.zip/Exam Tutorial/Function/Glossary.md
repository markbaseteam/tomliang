Statistics:is the study of collection organization, analysis and interpretation of data.

Blunder(gross error):  caused by mistakes eliminated by check
Systematic errors: influences the results always in the same sense.
(poor calibration)

Random error: remain unknown.





