## Template

| Problem Type                      | Code                                 |
| --------------------------------- | ------------------------------------ |
| Constraint for Level              | FB_=[sum(h)];                        |
| Constraint for Trila, Combination | FB_=[sum(y);sum(x);xyRotation(y,x)]; |
| Constraint for scaling            | FB_=[a^2+b^2+c^2-1];                 |
| (Or) Free Combination Like        | FB_=[func1; func2, ...]                                     |
 
 