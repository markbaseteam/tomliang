```matlab
function [L_i,X_i] = findDIR()
```

## Template 

```matlab
[L_i,X_i] = findDIR()

```

## Description 
automatic find the index of direction variable in L_ and X_
rule is ["w","W","DIR","dir","Dir","AN","an"]

 