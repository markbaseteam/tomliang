## A
AnalyzeEList(Elist);




```matlab
Elist=["Free_=||"
	"Free_data=[]"
	"L_=|L [3 1]|"
	"L_data=[3;1.5;0.2]"
	"X_=|x|y|"
	"X_data=[]"];

Elist=["Free_=||"
	"Free_data=[]"
	"L_=|L [3 1]|"
	"L_data=[3;1.5;0.2]"
	"X_=|x|y|"
	"X_data=[1.5;1.5]"
	"LB_=|cons|"
	"LB_data=[0]"
	];

```	





