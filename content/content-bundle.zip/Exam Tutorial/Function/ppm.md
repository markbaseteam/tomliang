function out = ppm(list,initial,ppm)
list: m The input distance
initial: mm 
ppm: (mm per km)
 
```
s_dis = [[ppm]](D_data, initial=1,ppm=2);  
```