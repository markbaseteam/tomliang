 Open Exam Tutorial folder, There will be two tutorials.

1. Template Code for Problem(Template code)
2. Customized LST pipeline(Hand by Hand building LST code)




-   Write Measurement right and its value (L_: Measurement symbol L_data : Measurement data)
    

-   Write Handwriting Error free point and its value (Free_: Free error symbol Free_data: Free error data)
    

-   Write Unkown and its value (X_: Unknown symbol X_data : Unknown data)