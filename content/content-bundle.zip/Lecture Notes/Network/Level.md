#### Concpet
Determine of elevation of point from level difference observation

#### Graph
![|200](https://i.imgur.com/Ik2Q5e4.png)

#### Calculation
Hab=Hb-Ha


### QUesiton




w, c, g

Relationship between P , L, number of setup.
- Weights inversely proportional to their length.  number of instrument setups.

 How to Project EDM to gauss kreger coordinate
- atomosphere correction, calibration, reduction into local plane, reference ellipsiod, GK

