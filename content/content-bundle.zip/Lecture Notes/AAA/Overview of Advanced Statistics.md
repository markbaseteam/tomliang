## Distribution
 
 

## Relationship 
Relation between [[F Distribution]] and [[Cai Distribution]]
$\chi_{f}^{2}=f \cdot F_{f, \infty}$
Relation between [[F Distribution]] and [[t Distribution]]
$t_{f}=\sqrt{F_{1, f}}$
Relation between [[F Distribution]] and [[Normal Distribution#Normal]]
$t_{\infty}=\sqrt{F_{1, \infty}} \sim N(0,1)$
 



## Statistical Test

Go find the leaflet

