### Propagation

[[Φ#Lr]]
[[Φ#NL]]
 
[[Propagation#ε]]
[[Propagation#η]]
[[Propagation#Δ]]
[[Propagation#σ]]
 
 1. [[Φ]]
 2.  [[Design Matrix]] linear or non-linear
 3. Set[[Σ, P]]
4. [[Propagation#σ]]
 

1. How to get sl arithmetric mean from n observation.
Write Function Model
A=[A1+A2+A3+...An]/n
SAA=Saa/n
How to linear the unlinear function?
- Using taylor series approximation to linear
 2. For double measurement l-l'
 Sll=Σd^2/2n
 Function Model
 SDD=Σd^2/n=E(ε^2)
 SLL=Σd^2/4n
 
What How to avoid is linearization Error
- When we neglect higher order, the error due to  H not << X0
- H must be a small value.

 How can we be sure that we have reached an appropriate solution?
 - Iterate until difference between <δ

Random deviations 𝛆 are usually not known in practice?
- Transition to variance and covariances.

- Functional model linear or nonlinear?
If linear, F directly given, if not, calculate partial deviation.

Whats the time we consider covariance, whats time variance only?
- If we interested in SyP, only not in correlation. We can compute SLL separetely by applying
- If we use for furthur computation, we must consider the covariances.

