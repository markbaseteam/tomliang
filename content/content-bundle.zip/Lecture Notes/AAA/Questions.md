




# Deficency
Difference with fixed error and freenetwork (5.p12)


Can we influence the impact of the control points on the inner geometry? (5. p17)


