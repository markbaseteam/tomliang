Mean,

Expectation,

True Value.


#### Code

General Tool/lib/Probability/Distribution.Statistic Value
 
