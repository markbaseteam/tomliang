- Until the correction is sufficient small (< two order of magnitude of result solution)



## Lr
$\hat{\mathbf{L}}-\boldsymbol{\Phi}(\widehat{\mathbf{X}}) = \mathbf{0}$

## GM
$\hat{\mathbf{L}}-\boldsymbol{\Phi}(\widehat{\mathbf{X}}) < \delta$ 
$max({\hat{x}}) \leq \epsilon$ 
(Magnitude: two order of result)
## L1
$\hat{\mathbf{L}}-\boldsymbol{\Phi}(\widehat{\mathbf{X}}) < \delta$ 
$max({\hat{x}}) \leq \epsilon$ 
$max(abs(\hat{V}_{last}-\hat{V}) \leq \epsilon$ 

## GH

$\Phi(\mathrm{v}, \widehat{\mathbf{X}})-\mathrm{c} \leq \delta$
$\max |\boldsymbol{\Phi}(\mathbf{v}, \widehat{\mathbf{X}})-\mathbf{c}| \leq \epsilon$
(Magnitude: two order of result)


 
