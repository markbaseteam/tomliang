### Linear
4. How to solve n>u
- We need know true value (?) but we dont know 
- Introduce residual
- Get observation equation. (but no unique solution?)
- Sove observation equation by minimum O. (but How)
- Normal Equation O'(x)=0 with its first derivative.;



### Non-Linear

How to Solve unlinear LST?
-  Direction Solution if possible
-  Heuristic Algorithm
- Linearised of normal equation and iterative.
- Linearised of original function and iterative.


### Question
1. Lr, Nr
2. Discuss different configure n, u
- n< u not unique
- = unique not reliability, no detect blunder
- n>u reliable, precision.

How to select initial solution if not?
- Must be closer to really solution or otherwise
- It will be trapped into local minimization.
- It cannot be convergent.

How often we stop the iteration
- Until the correction is sufficient small (< two order of magnitude of result solution)
- Until the L_hat-φ(X)~=0

How many and What  is error for LST? 
1. Computation and linearised error.
2. is error due to how far away from linearization problem to nonlineared problem.
 
What is mathematical model
- F+S


How to go with Constraint

1. Elimination by unserting
2. Determine the constraint minimum of vTPv under consideration of the constraints