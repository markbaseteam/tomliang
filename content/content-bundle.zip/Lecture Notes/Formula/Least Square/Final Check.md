#### Lr
$\hat{\mathbf{L}}-\boldsymbol{\Phi}(\widehat{\mathbf{X}}) = \mathbf{0}$

## NL
$\hat{\mathbf{L}}-\boldsymbol{\Phi}(\widehat{\mathbf{X}}) \stackrel{!}{\approx} \mathbf{0}$

## GH

$\Psi(\mathrm{v}, \widehat{\mathbf{X}})-\mathrm{c} \stackrel{!}{=} 0$
$\max |\boldsymbol{\Psi}(\mathbf{v}, \widehat{\mathbf{X}})-\mathbf{c}| \leq 10^{-7}$