1. $\varepsilon=\Delta_{1}+\Delta_{2}+\Delta_{3}+\ldots . .+\Delta_{q} ; \quad \varepsilon=\sum_{i=1}^{q} \Delta_{i}$


2. $E(\varepsilon)=\sum_{h=1}^{q} E\left(\Delta_{h}\right)=0$


3. $\sigma^{2}=E\left(\varepsilon^{2}\right)=\sum_{h=1}^{q} E\left(\Delta_{h}^{2}\right)=q \cdot \delta^{2}$



4. $x=\mu+\xi \rightarrow \xi=x-\mu \rightarrow d \xi=d x \rightarrow f(x)=f(\xi)$