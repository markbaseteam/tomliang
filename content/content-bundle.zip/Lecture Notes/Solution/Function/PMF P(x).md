Probability Mass Function


### Eqa
$\lim _{n \rightarrow \infty}\left\{h\left(x_{i}, \Delta x\right)\right\}=\lim _{n \rightarrow \infty}\left(\frac{k_{i}}{n}\right)=p\left(x_{i}, \Delta x\right)$