Cumulative Distribution Function
Also Called distribution function.
#### Define
$P(b)=P(L \leq b)-P(L \leq a)=F(b)-F(a)=\int_{0}^{b} f(x) d x$

#### Example

[[Example]]

#### Code

General Tool/lib/Probability/Distribution.Cumulative Frequency Distribution
 
 
 #### Derivative= [[PDF f(X)]]

$F_{X}(x)=\int_{-\infty}^{x} f_{X}(t) d t$




