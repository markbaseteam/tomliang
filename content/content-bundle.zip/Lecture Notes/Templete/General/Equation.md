```ad-example
collapse: close
title: Equation
color: 200, 200, 200


```
 