 

 **Question:**
 What its [[L,l]], [[Random Variable X]], [[Sample Space w]]
 
```ad-example
collapse: close
title: Answer
color: 200, 200, 200
 
```


