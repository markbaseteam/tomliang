```ad-example
collapse: close
title: Minimum distance for every tree to all streets:
color: 200, 200, 200
Select .gid as tree [[Group by]]
```