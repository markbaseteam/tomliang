#### Mat

#### Scalar

 #### Formula