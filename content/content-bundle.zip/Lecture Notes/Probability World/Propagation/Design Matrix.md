
##  Define
  
[[Linear Function]]
 
## A
$A=\frac{\partial \phi(\mathbf{X})}{\partial \mathbf{X}}$$\left.\right|_{x^0}$

## Full
$B=\frac{\partial \phi_B(\mathbf{X})}{\partial \mathbf{X}}$$\left.\right|_{x^0}$

## Partial
$B=\frac{\partial \phi_B(\mathbf{X})}{\partial \mathbf{X}}$$\left.\right|_{x^0}$
(X=Datum)
## G
$B=\frac{\partial \phi_B(\mathbf{X})}{\partial \mathbf{X}}$$\left.\right|_{x^0}$    
B=row_normalize(B)
## Pseudo
B_evl=eigvector(N)
 
## g-inverse
B= anyvalue

## GH
A=J1=$\frac{\partial \phi(\mathbf{X})}{\partial \mathbf{X}}$$\left.\right|_{x^0}$
J2=$\frac{\partial \phi(\mathbf{X})}{\partial \mathbf{L,v}}$$\left.\right|_{l^0,v^0}$
