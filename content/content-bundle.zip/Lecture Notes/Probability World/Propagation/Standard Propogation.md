
1.

$f(l)=a \cdot l \quad$ with $\quad a=$ const



VC propagation
$s_{f}=a \cdot s_{l}$


2.$f\left(l_{1}, l_{2}, \ldots, l_{n}\right)=l_{1} \pm l_{2} \pm \cdots \pm l_{n}$

$s_{f}=\sqrt{s_{l_{1}}^{2}+s_{l_{2}}^{2}+\cdots+s_{l_{n}}^{2}}$

3.$s_{l}=s_{l_{1}}=s_{l_{2}}=\cdots=s_{l_{n}}$

$s_{f}=\sqrt{n} \cdot s_{l}$


[[Sd]]
