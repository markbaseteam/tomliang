Stochastic Model 
## Define
 [[Variance]] or [[Weight P]]  of the observations 




## VCM
$S_{L L}=\boldsymbol{\Sigma}_{L L}=\left[\begin{array}{cccc}\sigma_{l_{1}}^{2} & & & \\ & \sigma_{l_{2}}^{2} & & 0 \\ & 0 & \ddots & \\ & & & \sigma_{l_{n}}^{2}\end{array}\right]$
## P
$\mathbf{Q}_{\mathrm{LL}}=\frac{1}{\sigma_{0}^{2}} \mathbf{\Sigma}_{1 \mathrm{~L}}$
$\mathrm{P}_{a, n}=\mathbf{Q}_{1 . \mathrm{L}}^{-1}$

## QA
W, 
1. How to represent unweighted.
- give same value to implictly created
2. How affect, if not?
- it will detect blunder
- adjusted parameter

## S
$\left[\begin{array}{cc}\boldsymbol{\Sigma}_{l l} & \mathbf{0} \\ \mathbf{0} & \boldsymbol{\Sigma}_{A A}\end{array}\right]$
