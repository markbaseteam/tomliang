Standard Deviation of an arithmetic mean

what is [[1Empirical Mean]]，只是某种特殊的l公式，适用于传播

$s_{\bar{l}}=\frac{s_{l}}{\sqrt{n}}$

指的是，可以通过多次测量观测.

也可以通过假定标准差每次都一样，然后单次测量估计, 运用[[Propagation]]