How close the measurement to a repeatable result.
In math we could use empirical SD.