### Discrete
$L=\left\{x_{1}, x_{2}, x_{3}, \ldots, x_{k}\right\}$
$W(X)=\left\{x_{1}, x_{2}, x_{3}, \ldots, x_{n}\right\}$

