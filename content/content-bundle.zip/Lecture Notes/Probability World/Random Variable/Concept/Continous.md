### Continous
 $l_{j} \in \langle a, b\rangle \quad$ with $\quad j=1,2,3, \ldots, k$
$W(X)=\langle a, b\rangle$