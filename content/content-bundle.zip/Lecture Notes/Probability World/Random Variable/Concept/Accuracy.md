How close the measurement to the true value.

In math we could use bias between expectation mu - empirical mean.