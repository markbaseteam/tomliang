### Define

$W(L)$ = {a, b, c, d} or <a, b>