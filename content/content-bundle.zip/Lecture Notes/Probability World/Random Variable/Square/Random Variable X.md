### Define
- Statistic polulation 
- certain range [[Sample Space w]]
- different range, [[L,l]]
- measurement has [[Probability P]] 
#### Mat
X

#### Scalar
$x_{i}$

### Example: 
[[Example#Represent Height of all student]]
[[Example#Distance Between two points]]


 