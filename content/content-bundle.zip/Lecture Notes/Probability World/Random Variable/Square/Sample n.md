### Define

- number of [[L,l]] /realizations
- subset of statistic polulation.