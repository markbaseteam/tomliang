Residual
#### Define
 
distance with mean
#### Mat
$\mathbf{v}=\mathbf{e} \cdot \bar{l}-\mathbf{l}$

#### Scalar
$\overline{v_{i}}=\bar{l}-l_{j}$
 