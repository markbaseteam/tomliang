 Measurement
 #### Define 
-  The observation are realizations of [[Random Variable X]].
-  All belong to sample space
 
#### Mat
$\mathbf{L}=\left[\begin{array}{c}l_{1} \\ l_{2} \\ \vdots \\ l_{n}\end{array}\right]$
 
#### Scalar
$l_{j}, j=1,2,3, \ldots, n$

 
 