Adjusted parameter x- 

### Define
 

 #### Mat
$\hat{X}, \hat{Y}=$ adjusted parameters
#### Scalar
$\hat{x}, \hat{y}=$ adjusted parameters
 #### Formula




