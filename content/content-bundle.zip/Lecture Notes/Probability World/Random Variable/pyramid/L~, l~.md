True Value
#### Mat
$\tilde{L}=\mu_{L}-\Delta$
#### Scalar
l_(j)

#### QA
 How to estimate true value given L. Unbias?
