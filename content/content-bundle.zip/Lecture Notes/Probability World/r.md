# Any
r=n-u
# Con
r=n-u+b
