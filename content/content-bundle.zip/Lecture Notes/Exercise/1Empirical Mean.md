![](https://i.imgur.com/eac2tGG.png)

VC
$s_{\bar{x}}^{2}=\left(\frac{1}{n}\right)^{2} s_{l_{1}}^{2}+\left(\frac{1}{n}\right)^{2} s_{l_{2}}^{2}+\cdots+\left(\frac{1}{n}\right)^{2} s_{l_{n}}^{2}=\frac{1}{n^{2}}\left(s_{l_{1}}^{2}+s_{l_{2}}^{2}+\cdots+s_{l_{n}}^{2}\right)$

if same precision

$S_{\bar{x}}=\frac{s_{l}}{\sqrt{n}}$