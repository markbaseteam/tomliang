## L,l

$\boldsymbol{\phi}_{B}(\mathbf{X})=\mathbf{c}$
 
$\mathbf{w}=\boldsymbol{\phi}_{B}\left(\mathbf{X}^{0}\right)-\mathbf{c}$
for condition
$\boldsymbol{\Psi}(\mathbf{l}+\mathbf{v}, \mathbf{x})=\mathbf{c}_1$

 
##  GM
$\boldsymbol{\phi}_B(\mathbf{X})=\mathbf{c}$
[[Overview Of Network]]


##  GH
$\boldsymbol{\phi}_B(\mathbf{X})=\mathbf{c}$
[[Overview Of Network]]
