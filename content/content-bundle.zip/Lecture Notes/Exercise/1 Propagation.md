### Title
![](https://i.imgur.com/XPav4rQ.png)

wanted Sa
### Answer

1.41 mgon.

