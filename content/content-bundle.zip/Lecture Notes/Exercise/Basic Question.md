1. What is minimal configurations.  What is it defects?







1. n=u it has unique solution but not reliable and cannot detect the blunders