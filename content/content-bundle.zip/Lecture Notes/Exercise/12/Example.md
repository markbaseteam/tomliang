 

####  Height of all student

Sample Space:
- [[Disrete Random Variable]]

[[L,l]]:
- All student with certain population
- n students of this semester
- h<sub>j</sub>=height of student j ^7953f9


#### Distance Between two points

Sample Space:
- [[Discrete Random Variable]]

[[L,l]]:
- All possible measureing results
- n measurement
- l<sub>j</sub>=distance of measuring j. ^4c78c8